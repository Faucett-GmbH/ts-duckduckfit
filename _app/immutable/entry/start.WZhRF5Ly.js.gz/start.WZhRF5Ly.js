import{l as o,a as r}from"../chunks/Bjp7-FD7.js";export{o as load_css,r as start};
