import{l as o,b as r}from"../chunks/BE5G4kbi.js";export{o as load_css,r as start};
