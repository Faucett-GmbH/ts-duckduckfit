import{l as o,a as r}from"../chunks/CqM85mS3.js";export{o as load_css,r as start};
