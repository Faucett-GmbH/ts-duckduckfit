import{l as o,b as r}from"../chunks/DOxF3GXY.js";export{o as load_css,r as start};
