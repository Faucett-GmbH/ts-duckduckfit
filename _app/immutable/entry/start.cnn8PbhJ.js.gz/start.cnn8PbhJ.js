import{l as o,a as r}from"../chunks/Bhc2oFO1.js";export{o as load_css,r as start};
