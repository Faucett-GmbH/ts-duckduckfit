import{l as o,a as r}from"../chunks/XcFCH7rj.js";export{o as load_css,r as start};
