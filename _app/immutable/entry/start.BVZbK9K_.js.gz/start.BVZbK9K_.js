import{l as o,a as r}from"../chunks/Dc6Jge8o.js";export{o as load_css,r as start};
