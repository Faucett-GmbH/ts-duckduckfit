import{l as o,a as r}from"../chunks/D6qWY_Zm.js";export{o as load_css,r as start};
