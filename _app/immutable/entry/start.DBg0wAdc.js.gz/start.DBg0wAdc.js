import{l as o,a as r}from"../chunks/DOlW7_5R.js";export{o as load_css,r as start};
