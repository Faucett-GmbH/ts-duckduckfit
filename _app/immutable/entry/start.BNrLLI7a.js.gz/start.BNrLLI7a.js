import{l as o,b as r}from"../chunks/QkImwR1G.js";export{o as load_css,r as start};
