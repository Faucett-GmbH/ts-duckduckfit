import{l as o,b as r}from"../chunks/DLlQQ697.js";export{o as load_css,r as start};
