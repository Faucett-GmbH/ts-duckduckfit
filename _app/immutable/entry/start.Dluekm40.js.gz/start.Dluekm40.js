import{l as o,a as r}from"../chunks/B7pAljJq.js";export{o as load_css,r as start};
