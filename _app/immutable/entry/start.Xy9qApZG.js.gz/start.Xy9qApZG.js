import{l as o,a as r}from"../chunks/DT3h5Cnk.js";export{o as load_css,r as start};
