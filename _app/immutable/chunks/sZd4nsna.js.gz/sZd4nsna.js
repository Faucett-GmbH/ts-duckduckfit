import { D as o, F as t, G as c, u as l } from "./DvcnV1Iy.js";
function u(e) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
function r(e) {
  t === null && u(), c && t.l !== null ? a(t).m.push(e) : o(() => {
    const n = l(e);
    if (typeof n == "function") return n;
  });
}
function a(e) {
  var n = e.l;
  return n.u ?? (n.u = { a: [], b: [], m: [] });
}
export {
  r as o
};
