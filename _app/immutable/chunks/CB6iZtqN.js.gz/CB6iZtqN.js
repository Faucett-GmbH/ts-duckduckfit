import { x as _, b as o, H as f, h as a, y as u, z as d, A as i, B as s, g as r, C as c } from "./DvcnV1Iy.js";
let e;
function g() {
  e = void 0;
}
function p(h) {
  let t = null, l = a;
  var n;
  if (a) {
    for (t = r, e === void 0 && (e = c(document.head)); e !== null && (e.nodeType !== 8 || e.data !== u); ) e = d(e);
    e === null ? i(false) : e = s(d(e));
  }
  a || (n = document.head.appendChild(_()));
  try {
    o(() => h(n), f);
  } finally {
    l && (i(true), e = r, s(t));
  }
}
export {
  p as h,
  g as r
};
