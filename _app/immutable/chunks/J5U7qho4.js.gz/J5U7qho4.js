import{b as o,r as s}from"./CmvMZC_O.js";function a(r,e){return o+s(r,e)}export{a as r};
