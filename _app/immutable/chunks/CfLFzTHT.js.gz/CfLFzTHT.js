import { s as n, n as r, p as t } from "./BXKgk3Hl.js";
const u = { get error() {
  return t.error;
}, get route() {
  return t.route;
}, get status() {
  return t.status;
} }, e = { get from() {
  return r.current ? r.current.from : null;
}, get to() {
  return r.current ? r.current.to : null;
}, get type() {
  return r.current ? r.current.type : null;
}, get willUnload() {
  return r.current ? r.current.willUnload : null;
}, get delta() {
  return r.current ? r.current.delta : null;
}, get complete() {
  return r.current ? r.current.complete : null;
} };
Object.defineProperty(e, "current", { get() {
  throw new Error("Replace navigating.current.<prop> with navigating.<prop>");
} });
n.updated.check;
const c = u, o = e;
export {
  o as n,
  c as p
};
