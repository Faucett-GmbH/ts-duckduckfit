import"./NZTpNUN0.js";import"./CtMpMTma.js";import{m as c,a as i,b as l}from"./B28cWlqn.js";import{I as p,s as d}from"./DTpy6sEi.js";import{l as m,s as $}from"./Cpoff584.js";function y(e,o){const s=m(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const t=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56"}]];p(e,$({name:"loader-circle"},()=>s,{get iconNode(){return t},children:(a,f)=>{var r=c(),n=i(r);d(n,o,"default",{}),l(a,r)},$$slots:{default:!0}}))}export{y as L};
