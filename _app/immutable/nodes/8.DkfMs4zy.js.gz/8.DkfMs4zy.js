import { m as n, n as c, o as m, __tla as __tla_0 } from "../chunks/C-o1sGLL.js";
import { r as o } from "../chunks/B90CZVMX.js";
import "../chunks/KzIwl7iM.js";
import { b as r } from "../chunks/B7qIyRxi.js";
let _;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  let i;
  i = async (e) => {
    const t = decodeURIComponent(e.url.searchParams.get("username") || ""), a = decodeURIComponent(e.url.searchParams.get("userDocumentId") || "");
    try {
      await n(t, a);
    } catch (s) {
      console.error(s), c(m()), o(302, `${r}/signin`);
    }
    o(302, `${r}/`);
  };
  _ = Object.freeze(Object.defineProperty({
    __proto__: null,
    load: i
  }, Symbol.toStringTag, {
    value: "Module"
  }));
});
export {
  __tla,
  _ as universal
};
