import"../chunks/DsnmJJEf.js";import{i as ae}from"../chunks/Dt8rrK3f.js";import{aB as te,u as re,r as se,L as le,aC as S,a as q,b as m,p as O,f as T,D as oe,c as Q,d as i,s as k,g as s,t as $,H as w,a4 as ne,aD as I}from"../chunks/DKyuKv9V.js";import{d as ce,s as x}from"../chunks/Bvir9z7y.js";import{l as R,s as U,p as ie,r as de,i as j,a as fe}from"../chunks/BkpU17rM.js";import{I as V,s as W,a as ve,r as _e,e as H,i as A,b as pe,c as me,d as ue,g as E,f as he,h as F,j as G,k as ge,l as be,m as J,n as xe,o as ke,p as K,q as ye,t as $e}from"../chunks/C2UbbaYp.js";function we(e,a,f=a){te(e,"change",l=>{var o=l?e.defaultChecked:e.checked;f(o)}),(le&&e.defaultChecked!==e.checked||re(a)==null)&&f(e.checked),se(()=>{var l=a();e.checked=!!l})}function Me(e,a){const f=R(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.540.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const l=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];V(e,U({name:"moon"},()=>f,{get iconNode(){return l},children:(o,u)=>{var c=S(),_=q(c);W(_,a,"default",{}),m(o,c)},$$slots:{default:!0}}))}function Te(e,a){const f=R(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.540.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const l=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];V(e,U({name:"sun"},()=>f,{get iconNode(){return l},children:(o,u)=>{var c=S(),_=q(c);W(_,a,"default",{}),m(o,c)},$$slots:{default:!0}}))}var Ce=T(`<label class="inline-flex cursor-pointer items-center"><input/> <div class="peer relative h-6 w-11 rounded-full bg-gray-200 peer-checked:bg-blue-600 peer-focus:outline-none after:absolute after:start-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:after:translate-x-full peer-checked:after:border-white rtl:peer-checked:after:-translate-x-full dark:border-gray-600 dark:bg-gray-700 dark:peer-checked:bg-blue-600"></div> <span class="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"><!></span></label>`);function Le(e,a){O(a,!0);let f=ie(a,"checked",15,!1),l=de(a,["$$slots","$$events","$$legacy","children","checked"]);var o=Ce(),u=i(o);_e(u),ve(u,()=>({type:"checkbox",class:"peer sr-only",...l}));var c=k(u,4),_=i(c);oe(_,()=>a.children),s(c),s(o),we(u,f),m(e,o),Q()}const Ne=e=>{ge(e.currentTarget.value)},Pe=e=>{be(e.currentTarget.value)};var Se=T("<option> </option>"),qe=T("<option><!></option>"),ze=T('<form class="card flex flex-col"><h2> </h2> <div class="mb-2 flex flex-grow flex-row items-center"><label for="theme" class="me-2"> </label> <!></div> <div class="mb-2 flex flex-grow flex-row items-center"><label for="language"> </label> <select name="language" class="ms-2"></select></div> <div class="mb-2 flex flex-grow flex-row items-center"><label for="measurementSystem"> </label> <select class="ms-2" name="measurementSystem"></select></div></form>');function Ee(e,a){O(a,!1);const f=d=>{ke(d.currentTarget.checked?"light":"dark")};ae();var l=ze(),o=i(l),u=i(o,!0);s(o);var c=k(o,2),_=i(c),X=i(_,!0);s(_);var Y=k(_,2);{let d=ne(()=>J()==="light");Le(Y,{name:"theme",get checked(){return w(d)},onchange:f,children:(n,t)=>{var v=S(),h=q(v);{var p=r=>{Te(r,{})},M=r=>{Me(r,{})};j(h,r=>{J()==="light"?r(p):r(M,!1)})}m(n,v)},$$slots:{default:!0}})}s(c);var C=k(c,2),L=i(C),Z=i(L,!0);s(L);var g=k(L,2);g.__change=[Ne],H(g,5,()=>fe,d=>d,(d,n)=>{var t=Se(),v=i(t,!0);s(t);var h={};$(p=>{K(t,p),x(v,w(n)),h!==(h=w(n))&&(t.value=(t.__value=w(n))??"")},[()=>E()==w(n)]),m(d,t)}),s(g);var z;A(g),s(C);var B=k(C,2),N=i(B),ee=i(N,!0);s(N);var b=k(N,2);b.__change=[Pe],H(b,4,()=>["metric","imperial"],xe,(d,n)=>{var t=qe(),v=i(t);{var h=r=>{var y=I();$(P=>x(y,P),[()=>ye()]),m(r,y)},p=r=>{var y=I();$(P=>x(y,P),[()=>$e()]),m(r,y)};j(v,r=>{n==="imperial"?r(h):r(p,!1)})}s(t);var M={};$(r=>{K(t,r),M!==(M=n)&&(t.value=(t.__value=n)??"")},[()=>F()==n]),m(d,t)}),s(b);var D;A(b),s(B),s(l),$((d,n,t,v,h,p)=>{x(u,d),x(X,n),x(Z,t),z!==(z=v)&&(g.value=(g.__value=v)??"",G(g,v)),x(ee,h),D!==(D=p)&&(b.value=(b.__value=p)??"",G(b,p))},[()=>pe(),()=>me(),()=>ue(),E,()=>he(),F]),m(e,l),Q()}ce(["change"]);export{Ee as component};
