import { t as c, a as h } from "../chunks/C3b73btl.js";
import { i as l } from "../chunks/B2XQHBYJ.js";
import { p as v, f as u, t as g, a as x, c as s, r as e, s as _ } from "../chunks/DvcnV1Iy.js";
import { s as p } from "../chunks/DxMSxYl-.js";
import { p as o } from "../chunks/CJGhRLCx.js";
var d = c("<h1> </h1> <p> </p>", 1);
function w(m, i) {
  v(i, false), l();
  var r = d(), t = u(r), f = s(t, true);
  e(t);
  var a = _(t, 2), n = s(a, true);
  e(a), g(() => {
    var _a;
    p(f, o.status), p(n, (_a = o.error) == null ? void 0 : _a.message);
  }), h(m, r), x();
}
export {
  w as component
};
