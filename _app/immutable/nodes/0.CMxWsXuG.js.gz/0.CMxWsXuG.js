import{r as bt}from"../chunks/C4Gu0MGd.js";import"../chunks/NZTpNUN0.js";import{o as wt}from"../chunks/B07xaDOM.js";import{k as kt,v as Nt,l as E,w as Mt,b4 as at,y as zt,z as It,A as Pt,B as rt,U as nt,ay as R,ab as ot,aA as it,D as st,q as St,G as jt,aK as lt,aJ as ct,b5 as dt,M as Ct,C as Dt,F as U,Q as At,I as M,a as w,b as h,aI as Ht,p as tt,f as z,t as X,c as et,d as v,r as d,s as b,g as Lt,j as ut,i as ht}from"../chunks/Bp7a5Wgv.js";import{s as Tt}from"../chunks/DWn6cB8H.js";import{d as mt,s as F}from"../chunks/CvtWGm_s.js";import{c as V,s as L,a as B}from"../chunks/Jqpb2jq0.js";import"../chunks/IVZvQc6H.js";import{H as Zt,ap as Et,aq as qt,ar as Wt,as as Ot}from"../chunks/BTEaUJ4b.js";import{b as q}from"../chunks/Dh8AOo2j.js";import{D as Ft}from"../chunks/BjJv7_by.js";import{n as Bt,p as J}from"../chunks/DMQtKo5h.js";import"../chunks/CBNN8OxY.js";import{L as Gt}from"../chunks/DRdkwd82.js";import{I,s as P,e as Rt}from"../chunks/Dxvg61WF.js";import{l as S,s as j}from"../chunks/BfGgFdEn.js";import{c as Ut,t as ft,b as vt}from"../chunks/lz1PwSB-.js";import{i as W}from"../chunks/BE4WL_0p.js";const K=0,O=1,Q=2;function Vt(a,t,e,o,i){E&&Mt();var n=a,r=kt(),s=Ct,m=nt,_,u,x,N=r?ot(void 0):it(void 0,!1,!1),k=r?ot(void 0):it(void 0,!1,!1),l=!1;function p(c,f){l=!0,f&&(lt(g),ct(g),dt(s));try{c===K&&e&&(_?Dt(_):_=st(()=>e(n))),c!==K&&_&&U(_,()=>_=null),c!==O&&u&&U(u,()=>u=null),c!==Q&&x&&U(x,()=>x=null)}finally{f&&(dt(null),ct(null),lt(null),At())}}var g=Nt(()=>{if(m===(m=t()))return;let c=E&&at(m)===(n.data===zt);if(c&&(n=It(),Pt(n),rt(!1),c=!0),at(m)){var f=m;l=!1,f.then(y=>{f===m&&(R(N,y),p(O,!0))},y=>{if(f===m)throw R(k,y),p(Q,!0),k.v}),E?e&&(_=st(()=>e(n))):St(()=>{l||p(K,!0)})}else R(N,m),p(O,!1);return c&&rt(!0),()=>m=nt});E&&(n=jt)}const Jt=!0,Kt=!1,Qt=async a=>{await bt(),await a.parent()},Oe=Object.freeze(Object.defineProperty({__proto__:null,load:Qt,prerender:Jt,ssr:Kt},Symbol.toStringTag,{value:"Module"}));function Yt(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"m9 12 2 2 4-4"}]];I(a,j({name:"circle-check"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function Xt(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"m15 9-6 6"}],["path",{d:"m9 9 6 6"}]];I(a,j({name:"circle-x"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function te(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z"}],["path",{d:"m2.5 21.5 1.4-1.4"}],["path",{d:"m20.1 3.9 1.4-1.4"}],["path",{d:"M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z"}],["path",{d:"m9.6 14.4 4.8-4.8"}]];I(a,j({name:"dumbbell"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function ee(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]];I(a,j({name:"info"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function ae(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M4 12h16"}],["path",{d:"M4 18h16"}],["path",{d:"M4 6h16"}]];I(a,j({name:"menu"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function re(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"}],["circle",{cx:"12",cy:"12",r:"3"}]];I(a,j({name:"settings"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function ne(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}],["path",{d:"M12 9v4"}],["path",{d:"M12 17h.01"}]];I(a,j({name:"triangle-alert"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}function oe(a,t){const e=S(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.525.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["circle",{cx:"12",cy:"5",r:"3"}],["path",{d:"M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z"}]];I(a,j({name:"weight"},()=>e,{get iconNode(){return o},children:(i,n)=>{var r=M(),s=w(r);P(s,t,"default",{}),h(i,r)},$$slots:{default:!0}}))}var ie=Ht('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 523.49" fill="currentColor" class="svelte-1gdf6cp"><path d="M85.54,320.91h145.64c11,0,19.91,8.92,19.91,19.91h0c0,11-8.92,19.91-19.91,19.91H72.65c-8.54,0-23.99-1.96-31.42-5.36-15.88-7.26-25.82-23.16-27.36-39.86-.42-4.54-.84-9.09-1.47-13.61v-.06c-.73-5.18,5.5-8.28,9.26-4.64,5.11,4.96,12.19,10.17,21.98,14.68,13.12,6.05,27.46,9.01,41.91,9.01Z"></path><path d="M360.22,342.48c-.14-59.29-49.01-106.96-108.31-106.96h-28.89c-2.91,0-5.26,2.36-5.26,5.26v29.3c0,2.91,2.36,5.26,5.26,5.26h29.07c37.13,0,67.96,29.65,68.3,66.77.34,37.45-30.02,68.02-67.4,68.02H114.8c-11.66,0-21.11,9.45-21.11,21.11v14.12c0,2.54,2.06,4.6,4.6,4.6h154.7c59.21,0,107.37-48.24,107.22-107.49Z"></path><path d="M406.26,95.97c3.11,0,5.48-2.81,4.91-5.87-2.41-12.93-9.48-27.75-9.48-27.75C385.68,24.48,348.75,0,307.62,0,307.62,0,307.63,0,307.62,0,280.27,0,254.54,10.75,235.18,30.28c-19.37,19.53-29.9,45.36-29.67,72.72,0,.94.03,1.87.06,2.8,1.48,41.52,29.5,77.82,69.71,90.32l33.32,10.36.39.12c29.54,8.52,56.1,26.44,74.79,50.45,19.22,24.68,29.37,54.13,29.37,85.16,0,78-65.4,141.45-145.78,141.45h0c-11,0-19.91,8.92-19.91,19.91v15.26c0,2.57,2.08,4.66,4.66,4.66h15.26c49.48,0,96.02-18.79,131.05-52.91,35.18-34.26,54.55-79.85,54.55-128.37,0-39.98-13.06-77.89-37.77-109.63-23.78-30.54-57.5-53.33-94.98-64.19l-33.12-10.3c-24.09-7.49-40.86-29.07-41.74-53.72-.02-.57-.03-1.15-.04-1.72-.14-16.66,6.29-32.4,18.12-44.34,11.82-11.93,27.51-18.49,44.16-18.49,25.09,0,47.62,14.93,57.4,38.05l2.97,6.92c2.91,6.78,9.57,11.18,16.95,11.18h21.33Z"></path><path d="M375.85,108.76c-6.87,0-13.07-4.11-15.75-10.44h0c-4.28-10.13-15.97-14.87-26.1-10.58l-12.07,5.1c-3.46,1.47-5.08,5.46-3.62,8.93l5.1,12.07c8.93,21.11,29.51,34.75,52.43,34.75h93.22c17.08,0,30.93-13.85,30.93-30.93h0c0-4.91-3.98-8.9-8.9-8.9h-115.25Z"></path><path d="M179.13,234.87c-4.49-.34-11.57-1.07-17.85-2.61-42.82-11.45-74.3-36.05-93.68-71.5-6.69-12.25-10.89-24.12-13.51-33.87-3.81-14.17-16.37-24.23-31.02-24.95l-8.61-.42c-2.39-.12-4.47,1.63-4.77,4.01L.76,177.12c-4.62,31.93,12.43,62.53,38.71,80.32,13.96,9.45,30.24,14.45,47.07,14.45l74.75,3.06h17.47c2.72,0,4.93-2.21,4.93-4.93v-30.24c0-2.58-1.98-4.73-4.55-4.92Z"></path></svg>');function se(a){var t=ie();h(a,t)}const le=""+new URL("../assets/logo-horizontal.TsqDIa3F.webp",import.meta.url).href;function Y(a,t){ut(t,!1)}var ce=z('<div class="mr-2 flex flex-row justify-center"><div class="inline-block h-6 w-6 animate-spin"><!></div></div>'),de=z('<button class="btn primary icon flex"><!></button>'),fe=z('<a><!><span class="ms-4"> </span></a> <a><!><span class="ms-4"> </span></a> <a><!><span class="ms-4"> </span></a>',1),ve=z('<div class="flex flex-shrink flex-row min-h-fit justify-between border-b border-gray-100 bg-white dark:border-gray-900 dark:bg-gray-800"><div class="ms-2 flex flex-shrink flex-row items-center justify-center"><a class="flex flex-row items-center justify-center"><span class="inline-block h-8"><!></span> <img class="my-1 ms-2 inline-block h-6 max-sm:hidden" alt="DuckDuckFit"/></a> <!></div> <div class="me-2 flex flex-shrink flex-row"><div class="flex flex-col content-center justify-center m-1"><!></div></div></div>');function ue(a,t){tt(t,!0);let e=Lt(!1);var o=ve(),i=v(o),n=v(i),r=v(n),s=v(r);se(s),d(r);var m=b(r,2);d(n);var _=b(n,2);Vt(_,()=>Bt.complete,k=>{var l=ce(),p=v(l),g=v(p);Gt(g,{}),d(p),d(l),h(k,l)}),d(i);var u=b(i,2),x=v(u),N=v(x);Ft(N,{get open(){return ht(e)},set open(l){ut(e,l,!0)},button:l=>{var p=de(),g=v(p);ae(g,{}),d(p),h(l,p)},children:(l,p)=>{var g=fe(),c=w(g);c.__click=[Y,e];var f=v(c);te(f,{});var y=b(f),H=v(y,!0);d(y),d(c);var $=b(c,2);$.__click=[Y,e];var C=v($);oe(C,{});var D=b(C),G=v(D,!0);d(D),d($);var A=b($,2);A.__click=[Y,e];var T=v(A);re(T,{});var Z=b(T),pt=v(Z,!0);d(Z),d(A),X((_t,gt,yt,$t,xt)=>{L(c,"href",`${q}/workout-templates`),B(c,1,V({"default flex cursor-pointer flex-row justify-between p-2 hover:bg-gray-200 dark:hover:bg-gray-600":!0,"bg-black/10":J.route.id==="/(initted)/workout-templates"})),F(H,_t),L($,"href",`${q}/weight-tracker`),B($,1,gt),F(G,yt),L(A,"href",`${q}/settings/profile`),B(A,1,$t),F(pt,xt)},[()=>Zt(),()=>V({"default flex cursor-pointer flex-row justify-between p-2 hover:bg-gray-200 dark:hover:bg-gray-600":!0,"bg-black/10":J.route.id?.startsWith("/(initted)/weight-tracker")}),()=>Et(),()=>V({"default flex cursor-pointer flex-row justify-between p-2 hover:bg-gray-200 dark:hover:bg-gray-600":!0,"bg-black/10":J.route.id?.startsWith("/(initted)/settings")}),()=>qt()]),h(l,g)},$$slots:{button:!0,default:!0}}),d(x),d(u),d(o),X(()=>{L(n,"href",`${q}/`),L(m,"src",le)}),h(a,o),et()}mt(["click"]);function he(a){const t=a-1;return t*t*t+1}function me(a,{from:t,to:e},o={}){var{delay:i=0,duration:n=C=>Math.sqrt(C)*120,easing:r=he}=o,s=getComputedStyle(a),m=s.transform==="none"?"":s.transform,[_,u]=s.transformOrigin.split(" ").map(parseFloat);_/=a.clientWidth,u/=a.clientHeight;var x=pe(a),N=a.clientWidth/e.width/x,k=a.clientHeight/e.height/x,l=t.left+t.width*_,p=t.top+t.height*u,g=e.left+e.width*_,c=e.top+e.height*u,f=(l-g)*N,y=(p-c)*k,H=t.width/e.width,$=t.height/e.height;return{delay:i,duration:typeof n=="function"?n(Math.sqrt(f*f+y*y)):n,easing:r,css:(C,D)=>{var G=D*f,A=D*y,T=C+D*H,Z=C+D*$;return`transform: ${m} translate(${G}px, ${A}px) scale(${T}, ${Z});`}}}function pe(a){if("currentCSSZoom"in a)return a.currentCSSZoom;for(var t=a,e=1;t!==null;)e*=+getComputedStyle(t).zoom,t=t.parentElement;return e}function _e(a,t){Wt(t.notification.id)}var ge=z('<button><div class="mr-2 h-6 w-6 text-white"><!></div> <div class="flex-grow text-left text-white"> </div></button>');function ye(a,t){tt(t,!0);var e=ge();let o;e.__click=[_e,t];var i=v(e),n=v(i);{var r=u=>{Xt(u,{})},s=(u,x)=>{{var N=l=>{Yt(l,{})},k=(l,p)=>{{var g=f=>{ee(f,{})},c=(f,y)=>{{var H=$=>{ne($,{})};W(f,$=>{t.notification.type==="warning"&&$(H)},y)}};W(l,f=>{t.notification.type==="info"?f(g):f(c,!1)},p)}};W(u,l=>{t.notification.type==="success"?l(N):l(k,!1)},x)}};W(n,u=>{t.notification.type==="error"?u(r):u(s,!1)})}d(i);var m=b(i,2),_=v(m,!0);d(m),d(e),X(u=>{o=B(e,1,"m-1 flex flex-grow cursor-pointer flex-row items-center px-3 py-2 shadow",null,o,u),F(_,t.notification.message)},[()=>({"bg-green-600":t.notification.type==="success","bg-red-600":t.notification.type==="error","bg-blue-600":t.notification.type==="info","bg-yellow-600":t.notification.type==="warning"})]),h(a,e),et()}mt(["click"]);var $e=z("<div><!></div>"),xe=z('<div class="fixed left-1/2 top-0 z-[100000] -translate-x-1/2"><div class="flex flex-col"></div></div>');function be(a){var t=xe(),e=v(t);Rt(e,13,()=>Ot,o=>o.id,(o,i)=>{var n=$e(),r=v(n);ye(r,{get notification(){return ht(i)}}),d(n),Ut(n,()=>me,null),ft(1,n,()=>vt,()=>({y:-64,duration:300})),ft(2,n,()=>vt,()=>({y:-64,duration:300})),h(o,n)}),d(e),d(t),h(a,t)}var we=z("<!> <!> <!>",1);function Fe(a,t){tt(t,!0),wt(()=>{document.body.classList.add("hydrated")});var e=we(),o=w(e);ue(o,{});var i=b(o,2);Tt(i,()=>t.children);var n=b(i,2);be(n),h(a,e),et()}export{Fe as component,Oe as universal};
